-- QD_MapLink: shares the player's position with the Queen's Domain map pages (acranon.github.io/queenscompanion/map/).
--
-- A few times a second it writes a tiny JSON file (position, facing, loaded levels) to
--   %TEMP%\QD_MapLink_position.json
-- and, at game start, launches helper\maplink_server.ps1, which serves that file on
-- http://127.0.0.1:47615/position (this PC only) so the map page in your browser can read it.
--
-- Sampling runs in the HUD draw hook (game thread, every frame) and is throttled to ~5 Hz. Every UE call is
-- wrapped in pcall; with no pawn (menus, loading) it writes {"pawn":false}. Nothing here changes the game.
--
-- "Collected" live updates: the game autosaves only every ~2 min, so the mod also watches what the game itself
-- records in its in-memory save (read-only hooks: it never calls or changes anything) and writes the changes since
-- the game started / last loaded a save to %TEMP%\QD_MapLink_delta.json; the helper lays them over the newest save:
--   SavableActor_C:"Save Data Index to World Save"(Index, Data) -> states[GUIDs[Index]] = Data (chests, breakables,
--                                                                   pickups, secret walls, levers, kill-once spawners)
--   ItemPickup_Base_C:SaveDropData / DeleteDropData               -> things lying on the ground (meal tickets, sacks)
--   SaveFunctions_C:SaveNamedData(Name, Data)                     -> named flags (ReadNote_<key>)
--   FS_GameInstance_C:"Load Game"(Death) / ForceLoadNewSlot      -> a save was (re)loaded: the changes start over

local PORT = 47615            -- must match the map page
local AUTOSTART_HELPER = true -- false: start helper\start_helper.bat yourself
local INTERVAL = 0.2          -- seconds between samples (5 Hz)
local HEARTBEAT = 2.0         -- rewrite unchanged data this often, so the page knows the game is alive
local LEVEL_INTERVAL = 2.0    -- seconds between reads of the loaded streaming levels
local HUD_CLASS = "/Game/Player/Assets/Input/FS_HUD.FS_HUD_C"
local HUD_FUNC = "ReceiveDrawHUD"

local PREFIX = "[QD_MapLink] "
local function log(message)
    print(PREFIX .. tostring(message) .. "\n")
end

local source_path = (debug.getinfo(1, "S") or {}).source or ""
local script_dir = source_path:match("^@(.*[/\\])") or ""
local mod_dir = (script_dir:gsub("[Ss]cripts[/\\]$", ""))
local temp_dir = os.getenv("TEMP") or os.getenv("TMP")
local OUT_PATH = temp_dir and (temp_dir .. "\\QD_MapLink_position.json") or (mod_dir .. "position.json")
local DELTA_PATH = temp_dir and (temp_dir .. "\\QD_MapLink_delta.json") or (mod_dir .. "delta.json")

local function safe(fn, ...)
    local ok, result = pcall(fn, ...)
    if ok then
        return result
    end
    return nil
end

local function is_valid(object)
    if object == nil then
        return false
    end
    local ok, value = pcall(function()
        return object:IsValid()
    end)
    return ok and value == true
end

local function unwrap(value)
    if value == nil then
        return nil
    end
    local ok, inner = pcall(function()
        return value:get()
    end)
    if ok then
        return inner
    end
    return value
end

-- JSON helpers -----------------------------------------------------------------

local function num(v, fmt)
    if type(v) ~= "number" or v ~= v or v == math.huge or v == -math.huge then
        return "null"
    end
    return string.format(fmt or "%.1f", v)
end

local function str(s)
    s = tostring(s or "")
    s = s:gsub('[%c"\\]', function(c)
        if c == '"' then return '\\"' end
        if c == "\\" then return "\\\\" end
        return string.format("\\u%04x", c:byte())
    end)
    return '"' .. s .. '"'
end

-- Atomic write: temp file, then rename. Windows rename() does not replace, so the old file is removed first;
-- the helper keeps serving its last good copy during that moment.
local function write_atomic(text, path)
    path = path or OUT_PATH
    local tmp = path .. ".tmp"
    local f = io.open(tmp, "wb")
    if not f then
        return false
    end
    f:write(text)
    f:close()
    os.remove(path)
    return os.rename(tmp, path) and true or false
end

-- Helper (local web server) ------------------------------------------------------

local function start_helper()
    if not AUTOSTART_HELPER or type(os.execute) ~= "function" then
        return
    end
    local ps1 = mod_dir .. "helper\\maplink_server.ps1"
    local f = io.open(ps1, "r")
    if not f then
        log("helper not found: " .. ps1)
        return
    end
    f:close()
    -- 'start' returns at once; the helper exits by itself when the port is taken or the game has closed.
    local cmd = string.format('start "" /min powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass '
        .. '-WindowStyle Hidden -File "%s" -Port %d -JsonPath "%s" -DeltaPath "%s"', ps1, PORT, OUT_PATH,
        DELTA_PATH)
    local ok, err = pcall(os.execute, cmd)
    if ok then
        log("helper started (port " .. PORT .. ")")
    else
        log("could not start helper: " .. tostring(err))
    end
end

-- Collected-state changes (delta file for the helper's /state) ---------------------
-- {"v":1,"session":"..","seq":n,"t":<unix s>,"load":{"t":..,"death":bool}|null,
--  "states":{"<GUID>":{"v":<int>,"t":..}}, "named":{"<name>":{"v":..,"t":..}},
--  "drops_added":[{"id","cls","pos":[x,y,z],"t"}], "drops_removed":[{"id","t"}]}
-- t = os.time() of the change; the helper keeps only changes newer than the save file it reads. A (re)load of a save
-- starts a new session with nothing in it. Written atomically, at most every DELTA_FLUSH s (dirty flag, flushed from
-- the hooks and the HUD hook).

local DELTA_FLUSH = 0.25
local DELTA_MAX = 4000        -- entries per table; beyond that new changes are ignored (never reached in play)

local delta = nil
local delta_dirty = false
local delta_last_write = -100.0
local delta_seq = 0
local delta_errors = 0

local function count(t)
    local n = 0
    for _ in pairs(t) do n = n + 1 end
    return n
end

local function delta_reset(load_info)
    delta = {
        session = string.format("%d-%d", os.time(), math.random(0, 999999)),
        load = load_info,
        states = {}, named = {}, added = {}, removed = {},
    }
    delta_dirty = true
end

local function delta_json()
    local parts = {}
    local function sorted_keys(t)
        local keys = {}
        for k in pairs(t) do keys[#keys + 1] = k end
        table.sort(keys)
        return keys
    end
    local st = {}
    for _, k in ipairs(sorted_keys(delta.states)) do
        local e = delta.states[k]
        st[#st + 1] = string.format('%s:{"v":%d,"t":%d}', str(k), e.v, e.t)
    end
    local nm = {}
    for _, k in ipairs(sorted_keys(delta.named)) do
        local e = delta.named[k]
        nm[#nm + 1] = string.format('%s:{"v":%d,"t":%d}', str(k), e.v, e.t)
    end
    local ad = {}
    for _, k in ipairs(sorted_keys(delta.added)) do
        local e = delta.added[k]
        local pos = "null"
        if e.pos then
            pos = string.format("[%s,%s,%s]", num(e.pos[1]), num(e.pos[2]), num(e.pos[3]))
        end
        ad[#ad + 1] = string.format('{"id":%s,"cls":%s,"pos":%s,"t":%d}', str(k), str(e.cls), pos, e.t)
    end
    local rm = {}
    for _, k in ipairs(sorted_keys(delta.removed)) do
        rm[#rm + 1] = string.format('{"id":%s,"t":%d}', str(k), delta.removed[k])
    end
    local load = "null"
    if delta.load then
        load = string.format('{"t":%d,"death":%s}', delta.load.t, delta.load.death and "true" or "false")
    end
    parts[#parts + 1] = string.format('{"v":1,"session":%s,"seq":%d,"t":%d,"load":%s', str(delta.session), delta_seq,
        os.time(), load)
    parts[#parts + 1] = ',"states":{' .. table.concat(st, ",") .. "}"
    parts[#parts + 1] = ',"named":{' .. table.concat(nm, ",") .. "}"
    parts[#parts + 1] = ',"drops_added":[' .. table.concat(ad, ",") .. "]"
    parts[#parts + 1] = ',"drops_removed":[' .. table.concat(rm, ",") .. "]}"
    return table.concat(parts)
end

local function delta_flush(force)
    if not delta_dirty or delta == nil then
        return
    end
    local now = os.clock()
    if not force and now - delta_last_write < DELTA_FLUSH then
        return
    end
    delta_seq = delta_seq + 1
    if write_atomic(delta_json(), DELTA_PATH) then
        delta_dirty = false
        delta_last_write = now
    end
end

local function delta_error(where, err)
    delta_errors = delta_errors + 1
    if delta_errors <= 10 then
        log(where .. " hook error: " .. tostring(err))
    end
end

-- FGuid -> "%08X" x 4 (A, B, C, D as unsigned), the key format of SavableActorStates / ItemDrops (and markers' sg)
local function guid_hex(g)
    if g == nil then
        return nil
    end
    local out = {}
    for _, field in ipairs({ "A", "B", "C", "D" }) do
        local v = tonumber(safe(function() return g[field] end))
        if v == nil then
            return nil
        end
        v = math.tointeger(v) or math.floor(v)
        out[#out + 1] = string.format("%08X", v & 0xFFFFFFFF)
    end
    local hex = table.concat(out)
    if hex == "00000000000000000000000000000000" then
        return nil
    end
    return hex
end

local function actor_guid(actor, index)
    local guids = safe(function() return actor.GUIDs end)
    if guids == nil then
        return nil
    end
    return guid_hex(unwrap(safe(function() return guids[index + 1] end)))
end

local function int_param(p)
    local v = tonumber(unwrap(p))
    if v == nil then
        return nil
    end
    return math.tointeger(v) or math.floor(v)
end

local function on_save_index(self_param, index_param, data_param)
    local ok, err = pcall(function()
        if delta == nil then delta_reset(nil) end
        local actor = unwrap(self_param)
        local index, value = int_param(index_param), int_param(data_param)
        if not is_valid(actor) or index == nil or value == nil or index < 0 then
            return
        end
        local key = actor_guid(actor, index)
        if key == nil then
            return
        end
        local e = delta.states[key]
        if e == nil and count(delta.states) >= DELTA_MAX then
            return
        end
        if e == nil or e.v ~= value then
            delta.states[key] = { v = value, t = os.time() }
            delta_dirty = true
            delta_flush(false)
        end
    end)
    if not ok then delta_error("save index", err) end
end

local function on_named(self_param, name_param, data_param)
    local ok, err = pcall(function()
        if delta == nil then delta_reset(nil) end
        local name = unwrap(name_param)
        local key = safe(function() return name:ToString() end)
        if type(key) ~= "string" then key = type(name) == "string" and name or nil end
        local value = int_param(data_param)
        if key == nil or key == "" or key == "None" or value == nil then
            return
        end
        local e = delta.named[key]
        if e == nil and count(delta.named) >= DELTA_MAX then
            return
        end
        if e == nil or e.v ~= value then
            delta.named[key] = { v = value, t = os.time() }
            delta_dirty = true
            delta_flush(false)
        end
    end)
    if not ok then delta_error("named data", err) end
end

local function on_drop_saved(self_param)
    local ok, err = pcall(function()
        if delta == nil then delta_reset(nil) end
        local actor = unwrap(self_param)
        if not is_valid(actor) then
            return
        end
        -- only real drops end up in the save's ItemDrops (the game checks IsADrop as well)
        if safe(function() return actor.IsADrop end) == false then
            return
        end
        local key = actor_guid(actor, 0)
        if key == nil then
            return
        end
        if delta.added[key] == nil and count(delta.added) >= DELTA_MAX then
            return
        end
        local cls = safe(function() return actor:GetClass():GetFName():ToString() end) or ""
        local loc = safe(function() return actor:K2_GetActorLocation() end)
        local x = loc and safe(function() return loc.X end)
        local y = loc and safe(function() return loc.Y end)
        local z = loc and safe(function() return loc.Z end)
        local pos = nil
        if type(x) == "number" and type(y) == "number" and type(z) == "number" then
            pos = { x, y, z }
        end
        delta.added[key] = { cls = cls, pos = pos, t = os.time() }
        delta.removed[key] = nil
        delta_dirty = true
        delta_flush(false)
    end)
    if not ok then delta_error("drop save", err) end
end

local function on_drop_deleted(self_param)
    local ok, err = pcall(function()
        if delta == nil then delta_reset(nil) end
        local actor = unwrap(self_param)
        if not is_valid(actor) then
            return
        end
        local key = actor_guid(actor, 0)
        if key == nil then
            return
        end
        if delta.removed[key] == nil and count(delta.removed) >= DELTA_MAX then
            return
        end
        delta.added[key] = nil
        delta.removed[key] = os.time()
        delta_dirty = true
        delta_flush(false)
    end)
    if not ok then delta_error("drop delete", err) end
end

local function on_load_game(self_param, death_param)
    local ok, err = pcall(function()
        local death = unwrap(death_param) == true
        delta_reset({ t = os.time(), death = death })
        delta_flush(true)
        log("save (re)loaded" .. (death and " after death" or "") .. ": live changes reset")
    end)
    if not ok then delta_error("load game", err) end
end

local function on_force_load(self_param)
    on_load_game(self_param, nil)
end

-- Sampling (runs inside the HUD hook) ----------------------------------------------

local last_sample = -1.0
local last_write = -1.0
local last_key = nil
local seq = 0
local errors = 0
local levels_time = -100.0
local levels_json = "[]"
local map_name = ""

-- Loaded streaming levels (short package names, e.g. "790_SG"). Several ways, each pcall'd, because not every
-- engine function is reachable from Lua in every build: names from GetWorldAssetPackageFName(), else the
-- PackageNameToLoad property, else the loaded level's outer (its UWorld, named like the package); visibility from
-- IsLevelVisible(), else "has a LoadedLevel and bShouldBeVisible". If the streaming list gives nothing, the world's
-- Levels array (every loaded level) is used instead. The first read that finds levels (or not) is logged once.
local levels_logged = nil     -- nil: not yet; then whether the last logged read found levels

local function short_level_name(name)
    if type(name) ~= "string" then
        name = name ~= nil and safe(function() return name:ToString() end) or nil
    end
    if type(name) ~= "string" or name == "" or name == "None" then
        return nil
    end
    name = name:match("([^/%.:]+)$") or name                 -- last path part
    name = name:gsub("^UEDPIE_%d+_", "")                      -- editor play-in-editor prefix
    name = name:gsub("_LevelInstance_%d+$", "")               -- LoadLevelInstance copies
    return name
end

local function streaming_name(ls)
    local n = short_level_name(safe(function() return ls:GetWorldAssetPackageFName() end))
    if n then return n, "fname" end
    n = short_level_name(safe(function() return ls.PackageNameToLoad end))
    if n then return n, "toload" end
    local level = safe(function() return ls.LoadedLevel end)
    if is_valid(level) then
        n = short_level_name(safe(function() return level:GetOuter():GetFName() end))
        if n then return n, "outer" end
    end
    return nil, "none"
end

local function streaming_visible(ls)
    local v = safe(function() return ls:IsLevelVisible() end)
    if type(v) == "boolean" then
        return v
    end
    local level = safe(function() return ls.LoadedLevel end)
    if not is_valid(level) then
        return false
    end
    local should = safe(function() return ls.bShouldBeVisible end)
    return should ~= false
end

local function read_levels(world)
    local names, seen, how = {}, {}, nil
    local count, err = 0, nil
    local function add(n)
        if n and not seen[n] and #names < 80 then
            seen[n] = true
            names[#names + 1] = str(n)
        end
    end
    local streaming = safe(function() return world.StreamingLevels end)
    if streaming ~= nil then
        local ok, e = pcall(function()
            streaming:ForEach(function(_, element)
                count = count + 1
                local ls = unwrap(element)
                if is_valid(ls) and streaming_visible(ls) then
                    local n, h = streaming_name(ls)
                    if n then
                        add(n)
                        how = how or h
                    end
                end
                return false
            end)
        end)
        if not ok then err = tostring(e) end
    end
    local persistent = safe(function() return world:GetFName():ToString() end)
    if #names == 0 then           -- fallback: every loaded level (their outer is the level's UWorld)
        local levels = safe(function() return world.Levels end)
        if levels ~= nil then
            pcall(function()
                levels:ForEach(function(_, element)
                    local level = unwrap(element)
                    if is_valid(level) then
                        local n = short_level_name(safe(function() return level:GetOuter():GetFName() end))
                        if n and n ~= persistent then
                            add(n)
                            how = how or "world.Levels"
                        end
                    end
                    return false
                end)
            end)
        end
    end
    if levels_logged == nil or (levels_logged == false and #names > 0) then
        levels_logged = #names > 0
        log(string.format("streaming levels: %d in list, %d loaded+visible (via %s)%s", count, #names, how or "-",
            err and (" error: " .. err) or ""))
    end
    return "[" .. table.concat(names, ",") .. "]"
end

local function rot_yaw(r)
    return r and safe(function() return r.Yaw end)
end

local function rot_pitch(r)
    return r and safe(function() return r.Pitch end)
end

local function sample(hud, now)
    local pc = safe(function() return hud.PlayerOwner end)
    local pawn = nil
    if is_valid(pc) then
        pawn = safe(function() return pc.Pawn end)
        if not is_valid(pawn) then
            pawn = safe(function() return pc:K2_GetPawn() end)
        end
    end

    local body, key
    local loc = is_valid(pawn) and safe(function() return pawn:K2_GetActorLocation() end) or nil
    local x = loc and safe(function() return loc.X end)
    local y = loc and safe(function() return loc.Y end)
    local z = loc and safe(function() return loc.Z end)

    if type(x) ~= "number" or type(y) ~= "number" or type(z) ~= "number" then
        key = "nopawn"
        body = '"pawn":false'
    else
        local actor_rot = safe(function() return pawn:K2_GetActorRotation() end)
        local control_rot = safe(function() return pc:GetControlRotation() end)
        local cam_mgr = safe(function() return pc.PlayerCameraManager end)
        local cam_rot = is_valid(cam_mgr) and safe(function() return cam_mgr:GetCameraRotation() end) or nil
        if now - levels_time >= LEVEL_INTERVAL then
            levels_time = now
            local world = safe(function() return pawn:GetWorld() end)
            if is_valid(world) then
                map_name = safe(function() return world:GetFName():ToString() end) or ""
                levels_json = read_levels(world)
            end
        end
        local yaw = rot_yaw(actor_rot)
        local cyaw = rot_yaw(cam_rot) or rot_yaw(control_rot)
        key = string.format("%.0f|%.0f|%.0f|%s|%s|%s|%s", x, y, z, num(yaw, "%.0f"), num(cyaw, "%.0f"),
            map_name, levels_json)
        body = string.format('"pawn":true,"x":%s,"y":%s,"z":%s,"yaw":%s,"ctrl_yaw":%s,"cam_yaw":%s,"cam_pitch":%s,'
            .. '"map":%s,"levels":%s',
            num(x), num(y), num(z), num(yaw), num(rot_yaw(control_rot)), num(cyaw),
            num(rot_pitch(cam_rot) or rot_pitch(control_rot)), str(map_name), levels_json)
    end

    if key == last_key and now - last_write < HEARTBEAT then
        return
    end
    seq = seq + 1
    local text = string.format('{"v":1,"seq":%d,"t":%d,"clock":%.2f,%s}', seq, os.time(), now, body)
    if write_atomic(text) then
        last_key = key
        last_write = now
    end
end

local function on_hud_draw(self_param)
    local ok, err = pcall(function()
        if delta_dirty then
            delta_flush(false)   -- a burst of changes that ended inside the flush interval
        end
        local now = os.clock()
        if now - last_sample < INTERVAL then
            return
        end
        last_sample = now
        local hud = unwrap(self_param)
        if is_valid(hud) then
            sample(hud, now)
        end
    end)
    if not ok then
        errors = errors + 1
        if errors <= 5 then
            log("sample error: " .. tostring(err))
        end
    end
end

-- Hook registration (retried until each blueprint class is loaded) ----------------

local HOOKS = {
    { cls = HUD_CLASS, fn = HUD_FUNC, cb = on_hud_draw },
    { cls = "/Game/Blueprints/SaveSystem/SavableActor.SavableActor_C", fn = "Save Data Index to World Save",
      cb = on_save_index },
    { cls = "/Game/Blueprints/ItemPickup_Base.ItemPickup_Base_C", fn = "SaveDropData", cb = on_drop_saved },
    { cls = "/Game/Blueprints/ItemPickup_Base.ItemPickup_Base_C", fn = "DeleteDropData", cb = on_drop_deleted },
    { cls = "/Game/Blueprints/SaveSystem/SaveFunctions.SaveFunctions_C", fn = "SaveNamedData", cb = on_named },
    { cls = "/Game/Blueprints/FS_GameInstance.FS_GameInstance_C", fn = "Load Game", cb = on_load_game },
    { cls = "/Game/Blueprints/FS_GameInstance.FS_GameInstance_C", fn = "ForceLoadNewSlot", cb = on_force_load },
}
local hooks_done = false

local function find_class_function(class_path, function_name)
    local class = safe(function() return StaticFindObject(class_path) end)
    if not is_valid(class) then
        return nil
    end
    local suffix = ":" .. function_name
    local found
    safe(function()
        class:ForEachFunction(function(function_object)
            local full_name = safe(function() return function_object:GetFullName() end)
            if type(full_name) == "string" and full_name:sub(-#suffix) == suffix then
                found = function_object
                return true
            end
            return nil
        end)
    end)
    if is_valid(found) then
        return found
    end
    return nil
end

local function install(h)
    local fn = find_class_function(h.cls, h.fn)
    if fn == nil then
        return false
    end
    local full_name = safe(function() return fn:GetFullName() end)
    if type(full_name) ~= "string" then
        return false
    end
    local ok, err = pcall(function()
        RegisterHook(full_name, h.cb)
    end)
    if ok then
        log("hook installed: " .. full_name)
    else
        h.failed = (h.failed or 0) + 1
        log("hook registration failed: " .. full_name .. ": " .. tostring(err))
    end
    return ok
end

local function ensure_hooks()
    local missing = 0
    for _, h in ipairs(HOOKS) do
        if not h.done and (h.failed or 0) < 3 then
            h.done = install(h) == true
            if not h.done then
                missing = missing + 1
            end
        end
    end
    if missing == 0 and not hooks_done then
        hooks_done = true
        log("hooks done -> " .. OUT_PATH .. ", " .. DELTA_PATH)
    end
    return hooks_done
end

safe(start_helper)
-- a fresh (empty) change set, so changes from an earlier game session never reach the map
safe(function()
    delta_reset(nil)
    delta_flush(true)
end)
-- One retry loop only (no ExecuteAsync as well): async callbacks may run in their own Lua state, and two
-- registrations would hook twice.
if type(LoopAsync) == "function" then
    LoopAsync(2000, function()
        if not hooks_done then
            safe(ensure_hooks)
        end
        return hooks_done   -- true stops the loop once every hook is in
    end)
end
log("initialized")
