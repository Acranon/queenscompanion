@echo off
rem QD_MapLink helper, started by hand. Only needed if it does not start with the game
rem (the mod normally starts it hidden). Keep this window open while you play; it closes
rem by itself about 10 seconds after Queen's Domain exits. Ctrl+C stops it.
title QD_MapLink helper (http://127.0.0.1:47615/position)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0maplink_server.ps1" -Console
