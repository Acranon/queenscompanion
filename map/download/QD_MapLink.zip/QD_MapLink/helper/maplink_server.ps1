# QD_MapLink helper: serves the position file written by the QD_MapLink mod to the map page in your browser.
#
#   GET http://127.0.0.1:47615/position  ->  {"helper":1,"proto":1,"age":<s since the mod last wrote>,"data":{...}|null,"pos":(same)}
#   GET http://127.0.0.1:47615/state     ->  {"helper":1,"proto":1,"age":<s since the save file was written>,
#                                             "data":{source, saved_at, states, drops, named}|null}: what your newest
#                                             save records as opened / collected (read-only parse, see below)
#
# - Listens on 127.0.0.1 only (this PC; nothing on your network can reach it). Read-only: fixed endpoints, no file browsing.
# - CORS: answers https://acranon.github.io (the map site; acranon.com kept for old links), local file pages (Origin "null") and http://localhost /
#   http://127.0.0.1 test servers; handles the OPTIONS preflight incl. Chrome's private/local network access header.
# - Only one copy runs: if the port is taken it exits quietly.
# - Exits by itself about 10 s after Queen's Domain has closed (it waits while the game has not started yet).
# - /state reads the newest of World0.sav / World0_Suspend_0.sav / World0_Suspend_1.sav (by the save's own
#   LastSaveTime) in %LOCALAPPDATA%\QueensDomain\Saved\SaveGames\<id>\. Read-only: a file is opened briefly with full
#   sharing (never written, never held open), only when its time stamp changed and it has been quiet for 2 s; a
#   half-written or unreadable file is retried later and the last good result is served meanwhile. The game
#   autosaves only about every 2 minutes, so the mod also writes what the game records in between to
#   %TEMP%\QD_MapLink_delta.json (see Get-Delta below); /state lays those changes over the save ("live" > 0).
# - Needs nothing installed: Windows PowerShell 5.1 (part of Windows 10/11), no admin rights.
param(
    [int]$Port = 47615,
    [string]$JsonPath = "",
    [string]$SaveDir = "",   # testing: a folder with World0*.sav (or <id>\ subfolders); default: the game's save folder
    [string]$DeltaPath = "", # changes since the last save, written by the mod (default %TEMP%\QD_MapLink_delta.json)
    [switch]$AssumeGame,     # testing: use the delta file although the game is not running
    [switch]$Console      # print status lines (used by start_helper.bat)
)

$ErrorActionPreference = 'Stop'
if (-not $JsonPath) { $JsonPath = Join-Path $env:TEMP 'QD_MapLink_position.json' }
if (-not $DeltaPath) { $DeltaPath = Join-Path $env:TEMP 'QD_MapLink_delta.json' }
$script:gameSeen = [bool]$AssumeGame
if (-not $SaveDir) { $SaveDir = $env:QD_MAPLINK_SAVEDIR }
if (-not $SaveDir) { $SaveDir = Join-Path $env:LOCALAPPDATA 'QueensDomain\Saved\SaveGames' }
$GameNames = @('QueensDomain-Win64-Shipping', 'QueensDomain')
$AllowedOrigins = @('https://acranon.github.io', 'https://acranon.com', 'https://www.acranon.com', 'null')
$Utf8 = New-Object System.Text.UTF8Encoding($false)

function Say([string]$msg) { if ($Console) { Write-Host ("[QD_MapLink] " + $msg) } }

$listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $Port)
$listener.ExclusiveAddressUse = $true
try { $listener.Start() } catch {
    Say "port $Port is already in use (helper already running?) - exiting"
    exit 0
}
Say "listening on http://127.0.0.1:$Port/position  (file: $JsonPath)"
Say "and http://127.0.0.1:$Port/state  (saves: $SaveDir; live changes: $DeltaPath)"
Say "this window can stay minimised; it closes by itself after the game exits (or press Ctrl+C)"

function Get-Origin($origin) {
    if (-not $origin) { return $null }
    if ($AllowedOrigins -contains $origin) { return $origin }
    if ($origin -match '^http://(127\.0\.0\.1|localhost)(:\d{1,5})?$') { return $origin }
    return $null
}

# Endpoints: name -> source. Each answer is
#   {"helper":1,"proto":1,"port":..,"name":"<endpoint>","age":<s since last write>,"data":{...}|null}
# and /position keeps "pos" as an alias of "data". /position serves the file the mod writes; /state is parsed from the
# game's save files (Get-StateFeed below). Adding a file feed later is one line here; a missing file answers data null.
$Feeds = [ordered]@{
    'position' = $JsonPath
    'state'    = '<save>'
}
$script:lastGood = @{}

function Read-Feed([string]$name) {
    if ($Feeds[$name] -eq '<save>') { return (Get-StateFeed $name) }
    # Opened with full sharing so the mod can delete/rename the file while we read it.
    $file = $Feeds[$name]
    $age = $null
    try {
        $fi = New-Object System.IO.FileInfo($file)
        if ($fi.Exists) {
            $age = [Math]::Round(([DateTime]::UtcNow - $fi.LastWriteTimeUtc).TotalSeconds, 2)
            $fs = [System.IO.File]::Open($file, 'Open', 'Read', ([System.IO.FileShare]::ReadWrite -bor [System.IO.FileShare]::Delete))
            try {
                $sr = New-Object System.IO.StreamReader($fs, $Utf8)
                $text = $sr.ReadToEnd().Trim()
            } finally { $fs.Dispose() }
            if ($text.Length -gt 1 -and $text.Length -lt 4194304 -and $text.StartsWith('{') -and $text.EndsWith('}')) {
                $script:lastGood[$name] = $text
            }
        }
    } catch { }   # file missing for a moment (atomic replace) or locked: serve the last good copy
    return (Format-Reply $name $age $script:lastGood[$name])
}

function Format-Reply([string]$name, $age, [string]$data) {
    if (-not $data) { $data = 'null' }
    $ageText = if ($null -ne $age) { $age.ToString([System.Globalization.CultureInfo]::InvariantCulture) } else { 'null' }
    $out = '{"helper":1,"proto":1,"port":' + $Port + ',"name":"' + $name + '","age":' + $ageText + ',"data":' + $data
    if ($name -eq 'position') { $out += ',"pos":' + $data }
    return $out + '}'
}

# ---------- /state: the game's save files (plain UE 4.27 GVAS), parsed read-only ----------
# SavableActorStates: {GUIDs[0] of a placed chest / pickup / secret wall / lever / kill-once spawner: value (>= 1 = used;
# spawners: kill count)}; ItemDrops: things lying on the ground (meal tickets, loot sacks, enemy drops); NamedSaveData:
# flags such as ReadNote_<key>. Same output as research/collected/qd_state.py in the map project.
function Read-FStr([byte[]]$b, [ref]$p) {
    $n = [BitConverter]::ToInt32($b, $p.Value); $p.Value += 4
    if ($n -eq 0) { return '' }
    if ($n -gt 65536 -or $n -lt -65536) { throw 'bad string' }
    if ($n -gt 0) { $s = [Text.Encoding]::GetEncoding(28591).GetString($b, $p.Value, $n - 1); $p.Value += $n; return $s }
    $s = [Text.Encoding]::Unicode.GetString($b, $p.Value, (-$n - 1) * 2); $p.Value += -$n * 2; return $s
}
function Read-Guid([byte[]]$b, [ref]$p) {
    $s = '{0:X8}{1:X8}{2:X8}{3:X8}' -f [BitConverter]::ToUInt32($b, $p.Value), [BitConverter]::ToUInt32($b, $p.Value + 4),
        [BitConverter]::ToUInt32($b, $p.Value + 8), [BitConverter]::ToUInt32($b, $p.Value + 12)
    $p.Value += 16; return $s
}
# property tag at $p -> hashtable (name, type, size, s/k/v, b) with $p at the value, or $null at 'None'
function Read-Tag([byte[]]$b, [ref]$p) {
    $name = Read-FStr $b $p
    if ($name -eq 'None' -or $name -eq '') { return $null }
    $t = @{ name = $name; type = (Read-FStr $b $p) }
    $t.size = [BitConverter]::ToInt64($b, $p.Value); $p.Value += 8
    if ($t.size -lt 0 -or $t.size -gt $b.Length) { throw 'bad tag size' }
    switch ($t.type) {
        'StructProperty' { $t.s = Read-FStr $b $p; $p.Value += 16 }
        'BoolProperty'   { $t.b = $b[$p.Value]; $p.Value += 1 }
        { $_ -in 'ByteProperty', 'EnumProperty', 'ArrayProperty', 'SetProperty' } { $t.i = Read-FStr $b $p }
        'MapProperty'    { $t.k = Read-FStr $b $p; $t.v = Read-FStr $b $p }
    }
    if ($b[$p.Value]) { $p.Value += 16 }
    $p.Value += 1
    return $t
}
function Read-Drop([byte[]]$b, [ref]$p) {
    $d = @{ cls = ''; pos = $null; items = @() }
    while ($true) {
        $t = Read-Tag $b $p
        if ($null -eq $t) { break }
        $end = $p.Value + $t.size
        $short = $t.name.Split('_')[0]
        if ($short -eq 'Pickupclass') { $d.cls = (Read-FStr $b $p).Split('.')[-1] }
        elseif ($short -eq 'Position') {          # Transform: Rotation, Translation, Scale3D
            while ($true) {
                $u = Read-Tag $b $p
                if ($null -eq $u) { break }
                if ($u.name -eq 'Translation') {
                    $d.pos = @([Math]::Round([BitConverter]::ToSingle($b, $p.Value), 1), [Math]::Round([BitConverter]::ToSingle($b, $p.Value + 4), 1),
                               [Math]::Round([BitConverter]::ToSingle($b, $p.Value + 8), 1))
                }
                $p.Value += $u.size
            }
        }
        elseif ($short -eq 'Inventory') {
            $q = [ref]($p.Value + 4); $n = [BitConverter]::ToInt32($b, $q.Value); $q.Value += 4
            for ($i = 0; $i -lt $n; $i++) {
                $k = Read-FStr $b $q
                if ($t.k -eq 'SoftObjectProperty') { [void](Read-FStr $b $q) }
                $d.items += , @($k, [BitConverter]::ToInt32($b, $q.Value)); $q.Value += 4
            }
        }
        $p.Value = $end
    }
    return $d
}
function Read-QDState([string]$file) {
    # one short read with full sharing: the game may write or replace the file at any time and we never hold it
    $fs = [IO.File]::Open($file, 'Open', 'Read', ([IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete))
    try {
        if ($fs.Length -lt 64 -or $fs.Length -gt 64MB) { throw 'bad size' }
        $b = New-Object byte[] $fs.Length; $got = 0
        while ($got -lt $b.Length) { $r = $fs.Read($b, $got, $b.Length - $got); if ($r -le 0) { throw 'short read' }; $got += $r }
    } finally { $fs.Close() }
    if ([Text.Encoding]::ASCII.GetString($b, 0, 4) -ne 'GVAS') { throw 'not a GVAS save' }
    $p = [ref]22; [void](Read-FStr $b $p)     # magic, save ver, package ver, engine ver (3 x u16 + changelist), branch
    $p.Value += 4; $n = [BitConverter]::ToInt32($b, $p.Value); $p.Value += 4 + 20 * $n
    [void](Read-FStr $b $p)
    $res = [ordered]@{ source = [IO.Path]::GetFileName($file); saved_at = $null; ticks = 0; states = @{}; drops = @(); named = (New-Object System.Collections.Hashtable ([StringComparer]::Ordinal)) }
    $complete = $false
    while ($p.Value -lt $b.Length) {
        $t = Read-Tag $b $p
        if ($null -eq $t) { $complete = $true; break }
        $end = $p.Value + $t.size
        if ($end -gt $b.Length) { throw 'truncated' }
        switch ($t.name) {
            'SavableActorStates' {
                $q = [ref]($p.Value + 4); $n = [BitConverter]::ToInt32($b, $q.Value); $q.Value += 4
                for ($i = 0; $i -lt $n; $i++) { $g = Read-Guid $b $q; $res.states[$g] = [BitConverter]::ToInt32($b, $q.Value); $q.Value += 4 }
            }
            'ItemDrops' {
                $q = [ref]($p.Value + 4); $n = [BitConverter]::ToInt32($b, $q.Value); $q.Value += 4
                for ($i = 0; $i -lt $n; $i++) {
                    $g = Read-Guid $b $q; $d = Read-Drop $b $q; $d.id = $g; $res.drops += [pscustomobject]$d
                }
            }
            'NamedSaveData' {
                $q = [ref]($p.Value + 4); $n = [BitConverter]::ToInt32($b, $q.Value); $q.Value += 4
                for ($i = 0; $i -lt $n; $i++) { $k = Read-FStr $b $q; $res.named[$k] = [BitConverter]::ToInt32($b, $q.Value); $q.Value += 4 }
            }
            'LastSaveTime' {
                $res.ticks = [BitConverter]::ToInt64($b, $p.Value)
                $res.saved_at = (New-Object DateTime $res.ticks).ToString('s')
            }
        }
        $p.Value = $end
    }
    if (-not $complete -or -not $res.ticks) { throw 'incomplete save' }   # partly written: tried again later
    return $res
}
# candidate saves: World<n>.sav and World<n>_Suspend_<k>.sav (not the _backup copies) in $SaveDir and its <id>\ folders
function Get-QDSaveFiles {
    $dirs = @($SaveDir) + @(Get-ChildItem -LiteralPath $SaveDir -Directory -ErrorAction SilentlyContinue | ForEach-Object { $_.FullName })
    foreach ($d in $dirs) {
        Get-ChildItem -LiteralPath $d -File -Filter 'World*.sav' -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -match '^World\d+(_Suspend_\d+)?\.sav$' }
    }
}
# ---------- live changes since the save (delta file written by the mod) ----------
# {"v":1,"session","seq","t","load":{"t","death"}|null,"states":{GUID:{v,t}},"named":{name:{v,t}},
#  "drops_added":[{id,cls,pos,t}],"drops_removed":[{id,t}]}; t = unix seconds of the change. The mod starts a new,
# empty session at game start and whenever the game (re)loads a save ("Load Game", incl. the reload after death).
# Rules here:
#  - a change counts only if it is newer than the save file used as the base (file time - 2 s: a change in the same
#    second may or may not be in the save; applying it twice is harmless);
#  - after a death reload (load.death) the game continues from World<n>.sav, so suspend saves written before that
#    reload are not used as the base (newer suspend saves are);
#  - if the base save goes back in time (an older save became the newest one) and the mod did not report a load
#    after the previous base, the changes made so far are dropped (safety net for a reload the hooks missed);
#  - nothing is applied before the game has been seen running (an old file from an earlier game session).
$script:delta = $null; $script:deltaKey = ''; $script:deltaFloor = $null
$Epoch = New-Object DateTime 1970, 1, 1, 0, 0, 0, ([DateTimeKind]::Utc)
function Get-Delta {
    try {
        $fi = New-Object IO.FileInfo($DeltaPath)
        if (-not $fi.Exists) { return }
        $key = '' + $fi.LastWriteTimeUtc.Ticks + '|' + $fi.Length
        if ($key -eq $script:deltaKey) { return }
        $fs = [IO.File]::Open($DeltaPath, 'Open', 'Read', ([IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete))
        try { $text = (New-Object IO.StreamReader($fs, $Utf8)).ReadToEnd() } finally { $fs.Dispose() }
        if ($text.Length -gt 8MB) { return }
        $d = $text | ConvertFrom-Json
        if ($d.v -ne 1 -or -not $d.session) { return }
        $script:delta = $d; $script:deltaKey = $key
    } catch { }   # mid-replace or half-written: keep the last good copy
}
# newest save by its own LastSaveTime; a file is parsed again only when its time stamp or size changed
$script:saveCache = @{}      # full path -> @{ key = 'mtime|size'; st = parsed state; mtime }
$script:saveFiles = @()      # candidate files from the last scan (full paths)
$script:stateJson = $null; $script:stateId = $null; $script:stateMtime = $null; $script:stateNext = [DateTime]::MinValue
$script:baseId = $null; $script:baseTicks = 0; $script:baseUnix = 0; $script:base = $null
function Get-StateFeed([string]$name) {
    $now = [DateTime]::UtcNow
    if ($now -ge $script:stateNext) {
        $script:stateNext = $now.AddSeconds(2)
        $list = @()
        foreach ($f in @(Get-QDSaveFiles)) {
            $key = '' + $f.LastWriteTimeUtc.Ticks + '|' + $f.Length
            $c = $script:saveCache[$f.FullName]
            # changed: parse once it has been quiet for 2 s (the game may still be writing); until then keep the old result
            if ((-not $c -or $c.key -ne $key) -and ($now - $f.LastWriteTimeUtc).TotalSeconds -ge 2) {
                try {
                    $c = @{ key = $key; st = (Read-QDState $f.FullName); mtime = $f.LastWriteTimeUtc }
                    $script:saveCache[$f.FullName] = $c
                } catch { }      # half-written, locked or damaged: retried on a later request
            }
            $list += $f.FullName
        }
        $script:saveFiles = $list
    }
    $d = $null
    if ($script:gameSeen) { Get-Delta; $d = $script:delta }
    # the base: newest save by LastSaveTime (after a death reload: not a suspend save from before it)
    $deathT = $null
    if ($d -and $d.load -and $d.load.death) { $deathT = [double]$d.load.t }
    $best = $null; $bestPath = $null
    foreach ($path in $script:saveFiles) {
        $c = $script:saveCache[$path]
        if (-not $c) { continue }
        if ($null -ne $deathT -and $c.st.source -match '_Suspend_' -and ($c.mtime - $Epoch).TotalSeconds -lt $deathT) { continue }
        if (-not $best -or $c.st.ticks -gt $best.st.ticks) { $best = $c; $bestPath = $path }
    }
    if ($best) {
        $id = $bestPath + '|' + $best.key
        if ($id -ne $script:baseId) {
            if ($script:baseId -and $best.st.ticks -lt $script:baseTicks -and $d) {
                # back in time: a reload. Unless the mod reported a load after the previous base, drop the changes so far.
                if (-not ($d.load -and [double]$d.load.t -ge $script:baseUnix - 2)) {
                    $script:deltaFloor = @{ session = $d.session; t = [Math]::Floor(($now - $Epoch).TotalSeconds) }
                    Say "an older save became the newest: earlier live changes dropped"
                }
            }
            $script:baseId = $id; $script:baseTicks = $best.st.ticks; $script:base = $best.st
            $script:baseUnix = [Math]::Floor(($best.mtime - $Epoch).TotalSeconds)
            $script:stateMtime = $best.mtime
            Say ("state: " + $best.st.source + ", saved " + $best.st.saved_at + ": " + $best.st.states.Count + " used, " + @($best.st.drops).Count + " lying on the ground")
        }
    }
    if ($script:base) {
        $floorT = 0
        if ($d -and $script:deltaFloor -and $script:deltaFloor.session -eq $d.session) { $floorT = $script:deltaFloor.t }
        $dk = '-'
        if ($d) { $dk = '' + $d.session + '/' + $d.seq }
        $id = $script:baseId + '|' + $dk + '|' + $floorT
        if ($id -ne $script:stateId) {
            $script:stateJson = Format-State $script:base $d ([Math]::Max($script:baseUnix - 2, $floorT)) $dk
            $script:stateId = $id
        }
    }
    $age = $null
    if ($script:stateJson) { $age = [Math]::Round(($now - $script:stateMtime).TotalSeconds, 1) }
    return (Format-Reply $name $age $script:stateJson)
}
# the save's state with the delta's changes at or after $minT laid over it -> JSON
#   {source, saved_at, states, drops, named, live: <changes applied>, live_at: <local time of the newest>|null, rev}
function Format-State($st, $d, [double]$minT, [string]$dk) {
    $states = $st.states; $named = $st.named; $drops = @($st.drops)
    $n = 0; $last = 0
    if ($d) {
        $states = $st.states.Clone(); $named = $st.named.Clone()
        foreach ($p in @($d.states.PSObject.Properties)) {
            if ([double]$p.Value.t -ge $minT) { $states[$p.Name] = [int]$p.Value.v; $n++; $last = [Math]::Max($last, [double]$p.Value.t) }
        }
        foreach ($p in @($d.named.PSObject.Properties)) {
            if ([double]$p.Value.t -ge $minT) { $named[$p.Name] = [int]$p.Value.v; $n++; $last = [Math]::Max($last, [double]$p.Value.t) }
        }
        $gone = @{}
        foreach ($r in @($d.drops_removed)) {
            if ($r -and [double]$r.t -ge $minT) { $gone[[string]$r.id] = 1; $n++; $last = [Math]::Max($last, [double]$r.t) }
        }
        $add = @()
        foreach ($a in @($d.drops_added)) {
            if ($a -and [double]$a.t -ge $minT -and $a.pos) {
                $gone[[string]$a.id] = 1; $n++; $last = [Math]::Max($last, [double]$a.t)
                $add += [pscustomobject]@{ cls = [string]$a.cls; pos = @($a.pos); items = @(); id = [string]$a.id }
            }
        }
        if ($gone.Count) { $drops = @($drops | Where-Object { -not $gone.ContainsKey([string]$_.id) }) }
        $drops = @($drops) + $add
    }
    $o = [ordered]@{ source = $st.source; saved_at = $st.saved_at; states = $states; drops = $drops; named = $named }
    $o.live = $n
    $o.live_at = $null
    if ($n) { $o.live_at = $Epoch.AddSeconds($last).ToLocalTime().ToString('s') }
    $o.rev = '' + $st.source + '|' + $st.ticks + '|' + $dk + '|' + $n
    return ($o | ConvertTo-Json -Depth 6 -Compress)
}

function Send($stream, [int]$code, [string]$reason, [string]$origin, [string]$body, [string[]]$extra) {
    $bytes = $Utf8.GetBytes($body)
    $h = "HTTP/1.1 $code $reason`r`n"
    $h += "Content-Type: application/json; charset=utf-8`r`n"
    $h += "Content-Length: $($bytes.Length)`r`n"
    $h += "Cache-Control: no-store`r`n"
    $h += "X-Content-Type-Options: nosniff`r`n"
    $h += "Vary: Origin`r`n"
    $h += "Connection: close`r`n"
    if ($origin) {
        $h += "Access-Control-Allow-Origin: $origin`r`n"
        $h += "Access-Control-Allow-Private-Network: true`r`n"
    }
    foreach ($e in $extra) { if ($e) { $h += "$e`r`n" } }
    $h += "`r`n"
    $hb = [System.Text.Encoding]::ASCII.GetBytes($h)
    $stream.Write($hb, 0, $hb.Length)
    if ($bytes.Length) { $stream.Write($bytes, 0, $bytes.Length) }
    $stream.Flush()
}

function Handle($client) {
    $client.ReceiveTimeout = 1000
    $client.SendTimeout = 1000
    $stream = $client.GetStream()
    # read the request head (max 8 KB; a request body is never needed)
    $buf = New-Object byte[] 8192
    $n = 0
    while ($n -lt $buf.Length) {
        $r = $stream.Read($buf, $n, $buf.Length - $n)
        if ($r -le 0) { break }
        $n += $r
        $head = [System.Text.Encoding]::ASCII.GetString($buf, 0, $n)
        if ($head.Contains("`r`n`r`n")) { break }
    }
    if ($n -eq 0) { return }
    $head = [System.Text.Encoding]::ASCII.GetString($buf, 0, $n)
    $lines = $head -split "`r`n"
    $parts = $lines[0] -split ' '
    if ($parts.Count -lt 2) { return }
    $method = $parts[0].ToUpperInvariant()
    $path = ($parts[1] -split '\?')[0]
    $hdr = @{}
    foreach ($l in ($lines | Select-Object -Skip 1)) {
        $i = $l.IndexOf(':')
        if ($i -gt 0) { $hdr[$l.Substring(0, $i).Trim().ToLowerInvariant()] = $l.Substring($i + 1).Trim() }
    }
    $origin = Get-Origin $hdr['origin']
    # only answer requests addressed to this PC by name (blocks DNS-rebinding tricks)
    $hostName = ("" + $hdr['host']).ToLowerInvariant()
    if ($hostName -ne "127.0.0.1:$Port" -and $hostName -ne "localhost:$Port") {
        Send $stream 403 'Forbidden' $null '{"error":"host"}' @()
        return
    }
    $feed = $path.TrimStart('/')
    if (-not $Feeds.Contains($feed)) {
        Send $stream 404 'Not Found' $origin '{"error":"not found"}' @()
        return
    }
    if ($method -eq 'OPTIONS') {
        $reqH = $hdr['access-control-request-headers']
        $extra = @('Access-Control-Allow-Methods: GET, OPTIONS', 'Access-Control-Max-Age: 600')
        if ($reqH -and $reqH -match '^[A-Za-z0-9\-, ]+$') { $extra += "Access-Control-Allow-Headers: $reqH" }
        Send $stream 204 'No Content' $origin '' $extra
        return
    }
    if ($method -ne 'GET' -and $method -ne 'HEAD') {
        Send $stream 405 'Method Not Allowed' $origin '{"error":"method"}' @('Allow: GET, OPTIONS')
        return
    }
    $body = Read-Feed $feed
    if ($method -eq 'HEAD') { $body = '' }
    Send $stream 200 'OK' $origin $body @()
}

$seenGame = $false
$goneSince = $null
$nextCheck = [DateTime]::UtcNow
try {
    while ($true) {
        if ($listener.Pending()) {
            $client = $listener.AcceptTcpClient()
            try { Handle $client } catch { } finally { $client.Close() }
            continue
        }
        Start-Sleep -Milliseconds 15
        $now = [DateTime]::UtcNow
        if ($now -ge $nextCheck) {
            $nextCheck = $now.AddSeconds(3)
            $running = @(Get-Process -Name $GameNames -ErrorAction SilentlyContinue).Count -gt 0
            if ($running) {
                if (-not $seenGame) { Say "game is running" }
                $seenGame = $true
                $script:gameSeen = $true
                $goneSince = $null
            } elseif ($seenGame) {
                if ($goneSince -eq $null) { $goneSince = $now }
                elseif (($now - $goneSince).TotalSeconds -ge 10) { Say "game closed - exiting"; break }
            }
        }
    }
} finally {
    $listener.Stop()
}
